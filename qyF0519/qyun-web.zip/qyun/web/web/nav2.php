  <header role="banner" id="fh5co-header">
    <div class="container">
      <!-- <div class="row"> -->
          <nav class="navbar navbar-default">
              <div class="navbar-header">
                <!-- Mobile Toggle Menu Button -->
          <a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"><i></i></a>
                  <a class="navbar-brand" href="/web/"><img src="<?php echo $logo ?>" /><?php echo $webtitle ?></a>  
              </div>
              <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                  <li class="active"><a href="index.php" data-nav-section="home"><span>网站首页</span></a></li>
                  <li><a href="index.php?name=<?php echo $name ?>#fh5co-our-services" data-nav-section="services"><span>产品介绍</span></a></li>
                  <li><a href="index.php?name=<?php echo $name ?>#fh5co-press" data-nav-section="press"><span>软件安装</span></a></li>
                  <li><a href="index.php?name=<?php echo $name ?>#fh5co-testimonials" data-nav-section="testimonials"><span>常见问题</span></a></li>
                  <li><a href="index.php?name=<?php echo $name ?>#fh5co-pricing" data-nav-section="pricing"><span>加入我们</span></a></li>
                  <li><a target="_blank" href="/user/login.php" class="btn btn-primary btn-sm">登录</a></li>
                  <li><a target="_blank" href="/user/reg.php?dl=<?php echo $daili ?>" class="btn btn-primary btn-sm">注册</a></li>
                </ul>
              </div>
          </nav>
      <!-- </div> -->
      </div>
  </header>