﻿<?php
/**
 * 安卓系统
**/
$mod='blank';
include("../api.inc.php");
$title='安卓系统';
?>
<?php include 'head.php';?>
<body id="ios">
	
	<?php include 'nav2.php';?>

	<div id="fh5co-press" data-section="press">
		<div class="container">
			<div class="row">
				<div class="col-md-12 section-heading text-center">
					<h2 class="single-animate animate-press-1">安卓系统安装流程</h2>
					<div class="row">
						<div class="col-md-8 col-md-offset-2 subtext single-animate animate-press-2">
							<h3>点击下载链接，即可马上开始使用</h3>
							<p>
								<a href="<?php echo $app1 ?>" class="btn btn-primary btn-sm" target="_blank">下载版本（1）</a>
								<a href="<?php echo $app2 ?>" class="btn btn-primary btn-sm" target="_blank">下载版本（2）</a>
							</p>
						</div>
					</div>
				</div>
			</div>
			<div class="row set">
				<div class="col-md-6 text">
					<div class="to-animate">
						<div class="fh5co-press-text">
							<h3 class="h2 fh5co-press-title"><i class="id">1</i>点击“登录/注册”</h3>
							<p>输入您的帐号密码，未注册请<a href="/user/reg.php" data-fancybox-type="iframe" class="various2">点击这里；</a><br>
							登录成功即可看到您的用户信息；</p>
							<p><a href="#" class="btn btn-primary btn-sm hide">Learn more</a></p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="to-animate">
						<img src="<?php echo $and_img1 ?>">
					</div>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-pricing">
		<div class="container">
			<div class="row set">
				<div class="col-md-6 text">
					<div class="to-animate">
						<div class="fh5co-press-text">
							<h3 class="h2 fh5co-press-title"><i class="id">2</i>点击“公告/线路”</h3>
							<p>此处确定电话卡所处运营商，选择安装对应线路；<br>
							切记不可开启wifi，这样是使用了wifi流量；</p>
							<p><a href="#" class="btn btn-primary btn-sm hide">Learn more</a></p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="to-animate">
						<img src="<?php echo $and_img2 ?>">
					</div>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-our-services">
		<div class="container">
			<div class="row set">
				<div class="col-md-6 text">
					<div class="to-animate">
						<div class="fh5co-press-text">
							<h3 class="h2 fh5co-press-title"><i class="id">3</i>点击“连接”</h3>
							<p>成功连接后会显示“已经成功连接”；<br>
							从顶部下滑通知栏，提示“已激活VPN”；</p>
							<p><a href="#" class="btn btn-primary btn-sm hide">Learn more</a></p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="to-animate">
						<img src="<?php echo $and_img3 ?>">
					</div>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-features">
		<div class="container">
			<div class="row set">
				<div class="col-md-6 text">
					<div class="to-animate">
						<div class="fh5co-press-text">
							<h3 class="h2 fh5co-press-title"><i class="id">4</i>检测是否使用“<?php echo $webtitle ?>”？</h3>
							<p>1，连接成功后，先查询自己流量剩余多少；<br>
							2，刷刷朋友圈，瞧瞧小新闻，看看小视频</p>
							<p>
							<a href="sms:10086?body=cxll" class="btn btn-primary btn-sm">移动-查询流量</a>
							<a href="sms:10010?body=cxll" class="btn btn-primary btn-sm">联通-查询流量</a>
							</p>
							<p><b>* 过20分钟后点上面“查询流量”如果只是使用了几KB，即成功使用免流</b></p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="to-animate">
						<img src="<?php echo $and_img4 ?>">
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php include 'copy.php';?>

	</body>
</html>
