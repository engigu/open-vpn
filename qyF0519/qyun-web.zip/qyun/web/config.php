<?php
/*数据库配置*/
$host = "localhost"; //MYSQL主机
$port = 3306; //MYSQL主机
$user = "root"; //MYSQL用户
$pwd ="qysql"; //MYSQL密码
$dbname = "ov"; //数据库名
?>