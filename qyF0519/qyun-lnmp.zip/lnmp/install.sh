#!/bin/bash
#QYUNL.COM
mkdir -p /home/wwwroot/default
mkdir -p /home/wwwlog/

firewall-cmd --permanent --zone=public --add-service=http   # 允许http服务端口访问
firewall-cmd --permanent --zone=public --add-service=https  # 允许https服务端口访问
firewall-cmd --reload   # 重启防火墙服务

# 安装ngixn
rpm -ivh http://nginx.org/packages/centos/7/noarch/RPMS/nginx-release-centos-7-0.el7.ngx.noarch.rpm
yum install -y nginx
mv /usr/share/nginx /home/wwwroot
cp -r /root/lnmp/conf/default.conf /etc/nginx/conf.d/default.conf
systemctl enable nginx.service
systemctl start nginx.service
# 安装mysql
yum install -y mariadb mariadb-server
systemctl restart mariadb.service
systemctl enable mariadb.service
# 安装php
yum -y --enablerepo=epel,remi,remi-php55 install php-fpm php-cli php-gd php-mbstring php-mcrypt php-mysqlnd php-opcache php-pdo php-devel php-xml
sed -i 's/;date.timezone =/date.timezone = PRC/g' /etc/php.ini
sed -i 's,listen = 127.0.0.1:9000,listen = /var/run/php-fpm/php5-fpm.sock,g' /etc/php-fpm.d/www.conf
sed -i 's/;listen.owner = nobody/listen.owner = nginx/g' /etc/php-fpm.d/www.conf
sed -i 's/;listen.group = nobody/listen.group = nginx/g' /etc/php-fpm.d/www.conf
sed -i 's/;listen.mode = 0660/listen.mode = 0660/g' /etc/php-fpm.d/www.conf
systemctl enable php-fpm.service
systemctl start php-fpm.service
# 重启lnmp
systemctl restart mariadb
systemctl restart nginx.service
systemctl restart php-fpm.service
systemctl restart crond.service
# 再次重启lnmp
systemctl restart mariadb
systemctl restart nginx.service
systemctl restart php-fpm.service
systemctl restart crond.service
#QYUNL.COM