<?php
//数据库信息
$host = "localhost" ;
$port = "3306" ;
$user = "root" ;
$pwd = "MySQLPass" ;
$dbname = "ov" ;

//管理员账号
$adminuser='admin';
$adminpass='SuperPass';
?>