<?php
$mode = $_GET["mode"];
include("mode/".$mode.".php");