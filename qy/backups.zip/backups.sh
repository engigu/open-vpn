#!/bin/bash
source /etc/openvpn/peizhi.cfg
if [ -f /etc/openvpn/peizhi.cfg ];
then
while true
do
echo -e "$(date +%Y年%m月%d日%k时%M分) 开始执行备份数据..."
mkdir /root/backups/ >/dev/null 2>&1
mkdir /root/backups/$(date +%Y-%m-%d) >/dev/null 2>&1
cd /root/backups/$(date +%Y-%m-%d)
mysqldump -h${localhost} -u${root} -p${mima} ov >ov.sql
echo -e "$(date +%Y年%m月%d日%k时%M分) 成功备份数据库，数据备份保存位于/root/backups/$(date +%Y-%m-%d),文件名：ov.sql"
sleep ${butime}
done
else
echo 配置文件读取失败，请检查... "</br>"
fi
#青云官网：www.qyunl.com