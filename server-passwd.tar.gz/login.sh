#!/bin/sh
user=$username
rp=$password
mysql -hlocalhost -uroot -pMySQLPass -e "use ov;SELECT pass FROM openvpn WHERE iuser='$user';">>log.txt
mysql -hlocalhost -uroot -pMySQLPass -e "use ov;SELECT irecv FROM openvpn WHERE iuser='$user';">>log.txt
mysql -hlocalhost -uroot -pMySQLPass -e "use ov;SELECT isent FROM openvpn WHERE iuser='$user';">>log.txt
mysql -hlocalhost -uroot -pMySQLPass -e "use ov;SELECT maxll FROM openvpn WHERE iuser='$user';">>log.txt
mysql -hlocalhost -uroot -pMySQLPass -e "use ov;SELECT i FROM openvpn WHERE iuser='$user';">>log.txt
mysql -hlocalhost -uroot -pMySQLPass -e "use ov;SELECT endtime FROM openvpn WHERE iuser='$user';">>log.txt
pass=$(sed -n 2p log.txt)
recv=$(sed -n 4p log.txt)
sent=$(sed -n 6p log.txt)
all=$(sed -n 8p log.txt)
i=$(sed -n 10p log.txt)
time=$(sed -n 12p log.txt)
now=$(date -d $(date +%Y-%m-%d) +%s)
rm -rf log.txt
if [ "$rp" == "$pass" ] && [ "$i" == "1" ] && [ "$[$recv+$sent]" -lt "$all" ] && [ "$time" -ge "$now" ];
then
exit 0
else
echo $(date +%Y年%m月%d日%k时%M分) "用户登录失败" "账号:"${username} "密码:"${password}>>user_error.log
exit 1
fi